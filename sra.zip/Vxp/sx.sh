clear
cd ..
cd bnr 
bash isp.sh
