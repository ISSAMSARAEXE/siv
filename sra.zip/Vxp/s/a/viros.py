import os
import time
import sys
#os.system('pkg install figlet')
os.system('pkg install zip -y;pkg install unzip -y')
os.system('cd exe;cd ss;unzip exe.zip')
os.system('clear')
v ='\033[0;35m'
W  = '\33[0m'
R  = '\33[1;31m'
G  = '\33[1;32m'
O  = '\33[1;33m'
B  = '\33[1;34m'
P  = '\33[1;35m'
C  = '\33[1;36m'
GR = '\33[1;37m'
rs = '\033[0;101m'
b_b = '\033[4;31m'
cc = '\033[0;91m'
pp = '\033[1;92m'
mc = 'please wait ... '
def ex(s):
    for c in s + '\n' :
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(330. / 50)
print(G+'please wait ... ')
print(R+'download file ...')
ex ('''''')
os.system('clear')
def pp(s):
    for c in s + '\n' :
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(10. / 150)
pp(G+'''I am not responsible for the error in use ''')
pp(R+'<type virus Trojans>')
def d():
    print(R+'''
▇▇▇◤▔▔▔▔▔▔▔◥▇▇▇
▇▇▇▏◥▇◣┊◢▇◤▕▇▇▇
▇▇▇▏▃▆▅▎▅▆▃▕▇▇▇
▇▇▇▏╱▔▕▎▔▔╲▕▇▇▇
▇▇▇◣◣▃▅▎▅▃◢◢▇▇▇
▇▇▇▇◣◥▅▅▅◤◢▇▇▇▇
▇▇▇▇▇◣╲▇╱◢▇▇▇▇▇
▇▇▇▇▇▇◣▇◢▇▇▇▇▇▇''')
    print(G+'''
############################################
## >\33[1;31m black hacker \33[1;32m                        ##
## > sara exe                             ##
## > issam exe                            ##
## > hacker squad                         ##
## > telegram : https://t.me/saraissamexe ##
############################################
''')
    print(GR)
    print(v)
    print('exit > exe')
    print('''[1] > virus Normal      [6] > virus phone lock 
[2] > facebook          [7] > virus hacker 
[3] > Instagram         [8] > virus hacker pubg
[4] > Whatsapp          [9] > virus hacker free fire
[5] > virus Trojans     [10] > virus x  
 ''')
    op = input(G+'virus number : ')
    if op =='1':
        os.system('cd exe;cd ss;cp vs1.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')
    if op =='2':
        os.system('cd exe;cd ss;cp vs2.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')
    if op =='3':
        os.system('cd exe;cd ss;cp vs3.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')
    
    if op =='4':
        os.system('cd exe;cd ss;cp vs4.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')
    if op =='5':
        os.system('cd exe;cd ss;cp vs1.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')            
    if op =='6':
        os.system('cd exe;cd ss;cp vs6.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')            
    if op =='7':
        os.system('cd exe;cd ss;cp vs7.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')            
    if op =='8':
        os.system('cd exe;cd ss;cp vs8.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')            
    if op =='9':
        os.system('cd exe;cd ss;cp vs9.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')
    if op =='10':
        os.system('cd exe;cd ss;cp vs10.apk /sdcard')
        os.system('clear')
        pp (G+'download virus please wait ... ')
        ex('')
        pp (R+'virus/sdcard')
        za = input(P+'Click enter : ')
        os.system('clear')
        while d():
            print('android virus ')            
    if op =='exe':
        os.system('exit')
        os.system('clear')
                    
    else:
        os.system('clear')
        while d():
            print('android virus ')


d()

