clear 
pkg install git -y
pkg install python -y
pkg install python2 -y
pkg install python3 -y
clear
git clone https://github.com/Issamexe/vr
cd vr 
pkg install zip 
pkg install unzip
cd vr 
unzip anr.zip
clear
rm -rif anr.zi
mv anr /sdcard
cd ..
rm -rif vr 
python3 Vxp.py
