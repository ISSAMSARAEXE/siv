import os
import time
#os.system('clear')
W  = '\33[0m'
R  = '\33[1;31m'
G  = '\33[1;32m'
O  = '\33[1;33m'
B  = '\33[1;34m'
P  = '\33[1;35m'
C  = '\33[1;36m'
GR = '\33[1;37m'
rs = '\033[0;101m'
b_b = '\033[4;31m'
p = ''
while p != 's':
    os.system('clear')
    print("password = s")
    print(R+"enter password ")
    p=input(G+'>>>> ')
    os.system('clear')
box=input(B+'enter install viros : ')


print("\33[1;32m--------\33[1;31mheloo\33[1;32m--------")
time.sleep(1)
print('\033[1;32m')
os.system('clear')
print('please wait [-\33[1;31m>               \33[1;32m]/ ')
time.sleep(0.5)
os.system('clear')
print('please wait [--\33[1;31m>              \33[1;32m]\  ')
time.sleep(0.5)
os.system('clear')
print('please wait [---\33[1;31m>             \33[1;32m]/ ')
time.sleep(0.5)
os.system('clear')
print('please wait [----\33[1;31m>            \33[1;32m]\  ')
time.sleep(0.5)
os.system('clear')
print('please wait [-----\33[1;31m>           \33[1;32m]/ ')
time.sleep(0.5)
os.system('clear')
print('please wait [------\33[1;31m>          \33[1;32m]\  ')
time.sleep(0.5)
os.system('clear')
print('please wait [-------\33[1;31m>         \33[1;32m]/ ')
time.sleep(0.5)
os.system('clear')
print('please wait [--------\33[1;31m>        \33[1;32m]\  ')
time.sleep(0.5)
os.system('clear')
print('please wait [---------\33[1;31m>       \33[1;32m]/  ')
time.sleep(0.5)
os.system('clear')
print('please wait [----------\33[1;31m>      \33[1;32m]\  ')
time.sleep(0.5)
os.system('clear')
print('please wait [-----------\33[1;31m>     \33[1;32m]/ ')
time.sleep(0.5)
os.system('clear')
print('please wait [------------\33[1;31m>    \33[1;32m]\  ')
time.sleep(0.5)
os.system('clear')
print('please wait [-------------\33[1;31m>   \33[1;32m]/  ')
time.sleep(0.5)
os.system('clear')
print('please wait [--------------\33[1;31m>  \33[1;32m]\  ')
time.sleep(0.5)
os.system('clear')
print('please wait [---------------\33[1;31m> \33[1;32m]/   ')
time.sleep(0.5)
os.system('clear')
print('please wait [----------------\33[1;31m>\33[1;32m]  ')
time.sleep(0.5)
os.system('clear')
print(R+"viros /sdcard/anr/all viros")
print(G+"""
	issam exe hacker
	sara exe hacker
	viros android
	tipe viros trojen 
	""")
time.sleep(2)
os.system("./vsp.sh







