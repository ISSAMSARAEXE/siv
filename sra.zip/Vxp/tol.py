import os
os.system('pkg install git -y')
os.system('pkg install python -y')
os.system('pkg install python2 -y')
os.system('pkg install python3 -y')



