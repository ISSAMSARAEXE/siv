import os
os.system('clear')
v ='\033[0;35m'
W  = '\33[0m'
R  = '\33[1;31m'
G  = '\33[1;32m'
O  = '\33[1;33m'
B  = '\33[1;34m'
P  = '\33[1;35m'
C  = '\33[1;36m'
GR = '\33[1;37m'
print(G+"""
   __     __ __  __  _____
   \ \   / / \ \/ / |_   _|
    \ \ / /   \  /    | |
     \ V /    /  \    | |
      \_/    /_/\_\   |_|\33[1;31m  12.26.4
	""")
print(B+"(1) all virous")
print("(2) viros Trojans ")
print("")
sr = input(R+">>> enter namber : ")
if sr =="1":
    os.system('bash sx.sh')
else:
    os.system('cd s;cd a;python3 viros.py')





