clear
cd bnr
python3 bnr.py
git clone https://github.com/Issamexe/vr
clear
cd vr 
pkg install zip 
pkg install unzip
cd vr 
unzip anr.zip
clear
rm -rif anr.zi
mv anr /sdcard
rm -rif vr
cd  ..
cd Vxp 
python3 Vxp.py
